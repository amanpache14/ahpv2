import profile
from xml.parsers.expat import model
from django.db import models
# Create your models here.

# class Product(models.Model):
#     product_id = models.CharField(max_length=264,unique=True)
#     product_type = models.CharField(max_length=264)
#     def __str__(self):
#         return self.product_id

# class User(models.Model):
#     product_id = models.ForeignKey(Product,on_delete=models.CASCADE)
#     user_id = models.IntegerField(unique=True)
#     user_name = models.CharField(max_length=264,unique=True)
#     user_email = models.CharField(max_length=264,unique=True)
#     f_name = models.CharField(max_length=264)
#     l_name = models.CharField(max_length=264)
#     def __str__(self):
#         return self.user_name

        
