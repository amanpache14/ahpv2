from django.http import JsonResponse
from django.shortcuts import render, redirect, HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate,login
from firebase import firebase

device_id ="O3KBC9LHZL"
fb = firebase.FirebaseApplication("https://ahpv2-e0eb0-default-rtdb.firebaseio.com",None)
# Create your views here.
def index(request):
    return render(request,"landing.html")

def dashboard(request):
    return render(request,'ahpUser/dashboard/index.html')

def logs(request):
    return render(request,"ahpUser/logs/Logs.html",{"logs":logs})

def signin(request):
    if request.method == 'POST':
        username = request.POST['userName']
        password = request.POST['passWord']

        user = authenticate(username=username, password=password)
        if user is not None:
            login(request, user)
            fname = user.first_name
            return render(request,'ahpUser/dashboard/index.html',{"fname":fname})
        else:
            messages.error(request,"Bad credentials try again")
            return redirect('signin')
    return render(request,'ahpUser/signin/signin.html')

def signup(request):

    if request.method == 'POST':
        username = request.POST['userName']
        fname = request.POST['fullName']
        gender = request.POST['gender']
        email = request.POST['email']
        phone = request.POST['phoneNumber']
        password = request.POST['passWord']
        password2 = password


        myuser = User.objects.create(username=username, email=email, password=password)
        myuser.first_name = fname
        myuser.phone_number = phone

        myuser.save()

        messages.success(request,"Account has been successfully created")
        return redirect("signin")
  
    return render(request,'ahpUser/signup/signup.html')
def signout(request):
    pass

def about(request):
    return render(request, 'ahpUser/about/about.html',{'insert_me':'Hello I am inserted'})
    

def getRtData(request):
    cloud_data = fb.get("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/sensors","")
    button_data = fb.get("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/buttons","")
    plant = fb.get("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/plant","")
    plant_data = {"plant":plant}
    merged = {}
    merged.update(cloud_data)
    merged.update(button_data)
    merged.update(plant_data)
    return JsonResponse(merged)

def uploadData(request):
    if request.method == 'POST':
        button = request.POST["button"]
        status = request.POST["status"]
        if status == "true":
            status = True
        if status == "false":
            status = False
        fb.put("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/buttons",button,status)
        return JsonResponse({"result":"Success"})
    return JsonResponse({"result":"Failure"})

def uploadPump(request):
    if request.method == 'POST':
        fb.put("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/buttons","phup",int(request.POST["phUp"]))
        fb.put("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/buttons","phdown",int(request.POST["phDown"]))
        fb.put("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/buttons","tdsa",int(request.POST["nutA"]))
        fb.put("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/buttons","tdsb",int(request.POST["nutB"]))
        fb.put("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/rtdata/buttons","water",int(request.POST["pumpDil"]))
        return JsonResponse({"result":"Success"})
    return JsonResponse({"result":"Failure"})

def getLogs(request):
    logs = fb.get("https://ahpv2-e0eb0-default-rtdb.firebaseio.com/"+device_id+"/logs/","")
    return JsonResponse(logs)
