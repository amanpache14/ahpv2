from django.urls import path
from django.contrib.auth.views import LoginView,LogoutView
from . import views

urlpatterns = [
    path('',views.index,name='indexUser'),
    path('about/',views.about,name='aboutUser'),
    path('dashboard/',views.dashboard,name="dashboard"),
    path('signin/',views.signin,name="signin"),
    path('signup/',views.signup,name="signup"),
     path('logs/',views.logs,name="logs" ),
    path('logout/',LogoutView.as_view(next_page='dashboard'),name="logout"),
   
    path('ajax/getRtData',views.getRtData,name="getRtData"),
    path('ajax/uploadData',views.uploadData,name="uploadData"),
    path('ajax/uploadPump',views.uploadPump,name="uploadPump"),
    path('ajax/getLogs',views.getLogs,name="getLogs")
]